<!DOCTYPE html>
<html>
<div id="fixedheader"class="navbar-collapse collapse">

 <div >
	<ul class="nav navbar-nav navbar-right">
		<li>
			<a style="color:black !important"href="logout.php">
				<input type="submit" value="Log Out" name ="log_out">
			</a>
		</li>
	</ul>
</div>
BLOG WORK
</div>
</html>