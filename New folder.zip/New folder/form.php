<!DOCTYPE html>

<html>
<link rel="stylesheet" href="css/bootstrap.min.css">
 <div class="container">
        

<body background="blue-pic-18.jpg">

<div class="container">
	<div class="col-md-4" style="width:96.333333%;color:white;font-size:20px"><h1>Start Blogging</h1><a href="signUp.php"><input class="btn btn-lg btn-primary " type="submit" name="create_acc" value="Create your Account"></a>
	
	<form action="home.php" method="post">
	<table align = "center">
	<tr>
		<th align="center" colspan="2" ><h2 style="color:#191970;font-size:50px !important">LogIn</h2></th>
		
	</tr>

	<tr>
		<td align="center">Email</td>
		<td><input class="form-control" placeholder="Email address"type="email" name="email" required><td>
	</tr>
	<tr>
		<td align="center">Password</td>
		<td><input class="form-control" placeholder="Email address"type="password" name="password" required><td>
	</tr>
	<tr><td align="center" colspan="2"><label>
                        <input type="checkbox" value="remember-me"> Remember me
                    </label></td> </tr>
	 
	<tr>
		
		<td align="center" colspan="2"><input class="btn btn-lg btn-primary btn-block btn-signin" type="submit" name="LogIn" value="submit here"><td>
	</tr>

                    
                </div>
	</table>
	</div>
	</form>
	
	</div>
</div>


</body>
</html>